## v1.0.0
Initial version

## v1.2.0
Added: New landing page 4 with some new elements..
Improved: Some improvements..
Fixed: Small issues.

## v1.3.0
Added: New landing page 5 with some new elements..
Improved: Compatible with NodeJS v18 instead of v14.
Improved: Compatible with Swiper 8 instead of 6.
Fixed: Small issues.